import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import sqlite3
import hashlib
from datetime import datetime

from database import get_connection, get_campuses
from models import create_user_role
from rules import CampusBookingPolicy


def view_campus_resources():
    campus = selected_campus.get()

    connection = get_connection()
    cursor = connection.cursor()
    cursor.execute(
        "SELECT resources.resource_name, resources.resource_type "
        "FROM resources "
        "INNER JOIN campuses "
        "ON resources.campus_id = campuses.campus_id "
        "WHERE campuses.campus_name = ?",
        (campus,)
    )
    resources = cursor.fetchall()
    connection.close()

    if resources:
        message = "Resources available at " + campus + ":\n\n"
        for resource_name, resource_type in resources:
            message += resource_name + " - " + resource_type + "\n"
        messagebox.showinfo("Campus Resources", message)
    else:
        messagebox.showinfo(
            "Campus Resources",
            "No resources are currently available at " + campus + "."
        )


def select_campus():
    campus = selected_campus.get()
    if campus:
        messagebox.showinfo("Campus Selected", "You selected " + campus)
    else:
        messagebox.showwarning(
            "No Campus Selected",
            "Please select a campus first."
        )


def show_booking_message():
    campus = selected_campus.get()
    messagebox.showinfo(
        "Booking Information",
        "Selected campus: " + campus +
        "\nUse Login to sign in before making a booking."
    )


def register_user():
    register_window = tk.Toplevel(root)
    register_window.title("User Registration")
    register_window.geometry("350x350")
    register_window.configure(bg="lightblue")

    tk.Label(register_window, text="Full Name:", bg="lightblue").pack(pady=5)
    full_name_entry = tk.Entry(register_window)
    full_name_entry.pack()

    tk.Label(register_window, text="Username:", bg="lightblue").pack(pady=5)
    username_entry = tk.Entry(register_window)
    username_entry.pack()

    tk.Label(register_window, text="Password:", bg="lightblue").pack(pady=5)
    password_entry = tk.Entry(register_window, show="*")
    password_entry.pack()

    tk.Label(register_window, text="Select Role:", bg="lightblue").pack(pady=5)
    role_variable = tk.StringVar(register_window)
    role_variable.set("Lecturer")
    tk.OptionMenu(
        register_window,
        role_variable,
        "Lecturer",
        "Campus Administrator",
        "System Operator"
    ).pack()

    def save_user():
        full_name = full_name_entry.get().strip()
        username = username_entry.get().strip()
        password = password_entry.get()
        role = role_variable.get()

        if not full_name or not username or not password:
            messagebox.showwarning(
                "Missing Information",
                "Please complete all fields.",
                parent=register_window
            )
            return

        password_hash = hashlib.sha256(password.encode("utf-8")).hexdigest()
        connection = get_connection()

        try:
            cursor = connection.cursor()
            cursor.execute(
                "INSERT INTO users "
                "(full_name, username, password_hash, role) "
                "VALUES (?, ?, ?, ?)",
                (full_name, username, password_hash, role)
            )
            connection.commit()
            messagebox.showinfo(
                "Registration Successful",
                "The user account has been created.",
                parent=register_window
            )
            register_window.destroy()
        except sqlite3.IntegrityError:
            messagebox.showerror(
                "Registration Failed",
                "That username already exists. Please choose another.",
                parent=register_window
            )
        finally:
            connection.close()

    tk.Button(
        register_window,
        text="Register",
        command=save_user
    ).pack(pady=15)


def open_booking_form(user_id):
    booking_window = tk.Toplevel(root)
    booking_window.title("Make a Booking")
    booking_window.geometry("440x560")
    booking_window.configure(bg="lightblue")

    campus_names = get_campuses()

    tk.Label(
        booking_window,
        text="Select Campus:",
        bg="lightblue"
    ).pack(pady=5)

    campus_variable = tk.StringVar(booking_window)
    if campus_names:
        campus_variable.set(campus_names[0])

    campus_menu = tk.OptionMenu(
        booking_window,
        campus_variable,
        *(campus_names if campus_names else ["No campuses available"])
    )
    campus_menu.pack()

    policy_label = tk.Label(
        booking_window,
        text="Booking policy: loading campus rules...",
        bg="lightblue",
        fg="darkblue",
        justify="left",
        wraplength=400,
        font=("Arial", 9, "bold")
    )
    policy_label.pack(pady=6)

    tk.Label(
        booking_window,
        text="Select Resource:",
        bg="lightblue"
    ).pack(pady=5)

    resource_variable = tk.StringVar(booking_window)
    resource_variable.set("")
    resource_menu = tk.OptionMenu(
        booking_window,
        resource_variable,
        ""
    )
    resource_menu.pack()

    selected_resource = {"id": None}

    availability_label = tk.Label(
        booking_window, text="Availability: enter a date and time, then check.",
        bg="lightblue", fg="darkblue", wraplength=360
    )
    availability_label.pack(pady=6)

    def check_resource_availability():
        booking_date = date_entry.get().strip()
        start_time = start_entry.get().strip()
        end_time = end_entry.get().strip()
        resource_id = selected_resource["id"]

        if not resource_id:
            availability_label.config(text="Availability: select a resource first.", fg="red")
            return
        try:
            parsed_date = datetime.strptime(booking_date, "%Y-%m-%d").date()
            start = datetime.strptime(start_time, "%H:%M")
            end = datetime.strptime(end_time, "%H:%M")
            if end <= start:
                raise ValueError
        except ValueError:
            availability_label.config(
                text="Availability: enter a valid date (YYYY-MM-DD), start/end times (HH:MM), and ensure end is later.",
                fg="red"
            )
            return

        requested_start = datetime.combine(parsed_date, start.time())
        if requested_start <= datetime.now():
            availability_label.config(
                text="Availability: past dates and times cannot be booked.",
                fg="red"
            )
            return

        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT COUNT(*) FROM bookings "
                "WHERE resource_id = ? AND booking_date = ? "
                "AND status = 'Confirmed' AND start_time < ? AND end_time > ?",
                (resource_id, booking_date, end_time, start_time)
            )
            occupied = cursor.fetchone()[0] > 0
            if occupied:
                availability_label.config(
                    text="Availability: UNAVAILABLE — this resource overlaps another confirmed booking.",
                    fg="red"
                )
            else:
                availability_label.config(
                    text="Availability: AVAILABLE for the selected date and time.",
                    fg="darkgreen"
                )
        except sqlite3.Error as error:
            availability_label.config(text="Availability check failed: " + str(error), fg="red")
        finally:
            connection.close()

    def update_resources(*args):
        # Display the policy for the currently selected campus so users can
        # see the rules before entering a booking.
        policy_connection = get_connection()
        try:
            policy_cursor = policy_connection.cursor()
            policy_cursor.execute(
                "SELECT max_duration, start_hour, end_hour "
                "FROM campuses WHERE campus_name = ?",
                (campus_variable.get(),)
            )
            policy_rules = policy_cursor.fetchone()
            if policy_rules:
                max_duration, opening_hour, closing_hour = policy_rules
                policy_label.config(
                    text=(
                        f"{campus_variable.get()} Booking Policy\n"
                        f"• Maximum duration: {float(max_duration):g} hour(s)\n"
                        f"• Operating hours: {int(opening_hour):02d}:00–{int(closing_hour):02d}:00"
                    ),
                    fg="darkblue"
                )
            else:
                policy_label.config(
                    text="Booking policy: no rules found for this campus.",
                    fg="red"
                )
        except (sqlite3.Error, TypeError, ValueError) as error:
            policy_label.config(
                text="Could not load booking policy: " + str(error),
                fg="red"
            )
        finally:
            policy_connection.close()

        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT resources.resource_id, resources.resource_name "
            "FROM resources "
            "INNER JOIN campuses "
            "ON resources.campus_id = campuses.campus_id "
            "WHERE campuses.campus_name = ? "
            "ORDER BY resources.resource_name",
            (campus_variable.get(),)
        )
        records = cursor.fetchall()
        connection.close()

        menu = resource_menu["menu"]
        menu.delete(0, "end")

        if records:
            for resource_id, resource_name in records:
                menu.add_command(
                    label=resource_name,
                    command=lambda rid=resource_id, name=resource_name: (
                        selected_resource.update({"id": rid}),
                        resource_variable.set(name)
                    )
                )
            selected_resource["id"] = records[0][0]
            resource_variable.set(records[0][1])
        else:
            selected_resource["id"] = None
            resource_variable.set("No resources available")

    if campus_names:
        campus_variable.trace_add("write", update_resources)
        update_resources()

    tk.Label(
        booking_window,
        text="Booking Date (YYYY-MM-DD):",
        bg="lightblue"
    ).pack(pady=5)
    date_entry = tk.Entry(booking_window)
    date_entry.pack()

    tk.Label(
        booking_window,
        text="Start Time (HH:MM, 24-hour):",
        bg="lightblue"
    ).pack(pady=5)
    start_entry = tk.Entry(booking_window)
    start_entry.pack()

    tk.Label(
        booking_window,
        text="End Time (HH:MM, 24-hour):",
        bg="lightblue"
    ).pack(pady=5)
    end_entry = tk.Entry(booking_window)
    end_entry.pack()

    tk.Button(
        booking_window, text="Check Resource Availability",
        command=check_resource_availability
    ).pack(pady=6)

    def submit_booking():
        booking_date = date_entry.get().strip()
        start_time = start_entry.get().strip()
        end_time = end_entry.get().strip()
        resource_id = selected_resource["id"]

        if not campus_names:
            messagebox.showerror(
                "No Campuses",
                "There are no campuses in the database.",
                parent=booking_window
            )
            return

        if not booking_date or not start_time or not end_time:
            messagebox.showerror(
                "Missing Information",
                "Please complete the date, start time and end time.",
                parent=booking_window
            )
            return

        try:
            parsed_date = datetime.strptime(booking_date, "%Y-%m-%d").date()
            start = datetime.strptime(start_time, "%H:%M")
            end = datetime.strptime(end_time, "%H:%M")
        except ValueError:
            messagebox.showerror(
                "Invalid Format",
                "Enter the date as YYYY-MM-DD and times as HH:MM.",
                parent=booking_window
            )
            return

        # Do not allow users to create bookings for a date that has already passed.
        if parsed_date < datetime.now().date():
            messagebox.showerror(
                "Past Booking Date",
                "You cannot create a booking for a date in the past. Please select today or a future date.",
                parent=booking_window
            )
            return

        if parsed_date == datetime.now().date():
            requested_start = datetime.combine(parsed_date, start.time())
            if requested_start <= datetime.now():
                messagebox.showerror(
                    "Booking Time Has Passed",
                    "For today's date, the booking start time must be in the future.",
                    parent=booking_window
                )
                return

        requested_start = datetime.combine(parsed_date, start.time())
        if requested_start <= datetime.now():
            messagebox.showerror(
                "Past Booking Not Allowed",
                "Bookings must start in the future. Choose a future date or time.",
                parent=booking_window
            )
            return

        if end <= start:
            messagebox.showerror(
                "Invalid Time",
                "The end time must be later than the start time.",
                parent=booking_window
            )
            return

        if resource_id is None:
            messagebox.showerror(
                "No Resource",
                "Please select an available resource.",
                parent=booking_window
            )
            return

        # Retrieve the selected campus's booking rules from the database.
        selected_campus = campus_variable.get()
        connection = get_connection()
        try:
            cursor = connection.cursor()

            cursor.execute(
                "SELECT max_duration, start_hour, end_hour "
                "FROM campuses WHERE campus_name = ?",
                (selected_campus,)
            )
            campus_rules = cursor.fetchone()

            if campus_rules is None:
                messagebox.showerror(
                    "Campus Not Found",
                    "Could not find booking rules for the selected campus.",
                    parent=booking_window
                )
                return

            max_duration, opening_hour, closing_hour = campus_rules
            policy = CampusBookingPolicy(
                selected_campus, max_duration, opening_hour, closing_hour
            )
            policy_error = policy.validate(start, end)
            if policy_error:
                messagebox.showerror(
                    "Campus Booking Policy", policy_error, parent=booking_window
                )
                return

            # Prevent overlapping bookings for the same resource.
            cursor.execute(
                "SELECT COUNT(*) FROM bookings "
                "WHERE resource_id = ? AND booking_date = ? "
                "AND status = 'Confirmed' "
                "AND start_time < ? AND end_time > ?",
                (resource_id, booking_date, end_time, start_time)
            )
            if cursor.fetchone()[0] > 0:
                messagebox.showerror(
                    "Resource Unavailable",
                    "This resource is already booked during that time.",
                    parent=booking_window
                )
                return

            cursor.execute(
                "INSERT INTO bookings "
                "(user_id, resource_id, booking_date, start_time, end_time, status) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    user_id,
                    resource_id,
                    booking_date,
                    start_time,
                    end_time,
                    "Confirmed"
                )
            )
            connection.commit()

            messagebox.showinfo(
                "Booking Successful",
                "Your booking has been saved successfully!",
                parent=booking_window
            )
            booking_window.destroy()
        except sqlite3.Error as error:
            messagebox.showerror(
                "Database Error",
                "The booking could not be saved:\n" + str(error),
                parent=booking_window
            )
        finally:
            connection.close()

    tk.Button(
        booking_window,
        text="Submit Booking",
        command=submit_booking
    ).pack(pady=15)




def manage_campus_resources():
    """Allow campus administrators to add, update, and remove resources."""
    campuses = get_campuses()
    if not campuses:
        messagebox.showerror("No Campuses", "No campuses are available in the database.")
        return

    window = tk.Toplevel(root)
    window.title("Campus Resource Management")
    window.geometry("800x570")
    window.configure(bg="lightblue")

    tk.Label(
        window,
        text="Manage Campus Resources",
        font=("Arial", 15, "bold"),
        bg="lightblue"
    ).pack(pady=10)

    campus_variable = tk.StringVar(window, value=campuses[0])
    tk.Label(window, text="Campus:", bg="lightblue").pack()
    tk.OptionMenu(window, campus_variable, *campuses).pack(pady=4)

    form = tk.Frame(window, bg="lightblue")
    form.pack(pady=8)

    tk.Label(form, text="Resource Name:", bg="lightblue").grid(row=0, column=0, padx=5, pady=5, sticky="e")
    name_entry = tk.Entry(form, width=30)
    name_entry.grid(row=0, column=1, padx=5, pady=5)

    tk.Label(form, text="Resource Type:", bg="lightblue").grid(row=1, column=0, padx=5, pady=5, sticky="e")
    type_entry = tk.Entry(form, width=30)
    type_entry.grid(row=1, column=1, padx=5, pady=5)

    columns = ("resource_id", "resource_name", "resource_type")
    table = ttk.Treeview(window, columns=columns, show="headings", height=12)
    table.heading("resource_id", text="Resource ID")
    table.heading("resource_name", text="Resource Name")
    table.heading("resource_type", text="Resource Type")
    table.column("resource_id", width=100, anchor="center")
    table.column("resource_name", width=300)
    table.column("resource_type", width=250)
    table.pack(fill="both", expand=True, padx=12, pady=8)

    def load_resources(*args):
        for item in table.get_children():
            table.delete(item)
        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT resources.resource_id, resources.resource_name, "
                "resources.resource_type FROM resources "
                "INNER JOIN campuses ON resources.campus_id = campuses.campus_id "
                "WHERE campuses.campus_name = ? ORDER BY resources.resource_name",
                (campus_variable.get(),)
            )
            for record in cursor.fetchall():
                table.insert("", "end", values=record)
        except sqlite3.Error as error:
            messagebox.showerror(
                "Database Error", "Could not load resources:\n" + str(error),
                parent=window
            )
        finally:
            connection.close()
        clear_fields()

    def clear_fields():
        name_entry.delete(0, tk.END)
        type_entry.delete(0, tk.END)
        for item in table.selection():
            table.selection_remove(item)

    def select_resource(event=None):
        selected = table.selection()
        if not selected:
            return
        values = table.item(selected[0], "values")
        name_entry.delete(0, tk.END)
        name_entry.insert(0, values[1])
        type_entry.delete(0, tk.END)
        type_entry.insert(0, values[2])

    def save_resource():
        name = name_entry.get().strip()
        resource_type = type_entry.get().strip()
        if not name or not resource_type:
            messagebox.showwarning(
                "Missing Information", "Enter both the resource name and type.",
                parent=window
            )
            return

        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT campus_id FROM campuses WHERE campus_name = ?",
                (campus_variable.get(),)
            )
            campus_row = cursor.fetchone()
            if campus_row is None:
                messagebox.showerror("Campus Not Found", "The selected campus was not found.", parent=window)
                return
            campus_id = campus_row[0]

            selected = table.selection()
            if selected:
                resource_id = table.item(selected[0], "values")[0]
                cursor.execute(
                    "SELECT COUNT(*) FROM resources WHERE campus_id = ? "
                    "AND LOWER(resource_name) = LOWER(?) AND resource_id != ?",
                    (campus_id, name, resource_id)
                )
            else:
                cursor.execute(
                    "SELECT COUNT(*) FROM resources WHERE campus_id = ? "
                    "AND LOWER(resource_name) = LOWER(?)",
                    (campus_id, name)
                )
            if cursor.fetchone()[0] > 0:
                messagebox.showerror(
                    "Duplicate Resource",
                    "A resource with this name already exists at this campus.",
                    parent=window
                )
                return

            if selected:
                resource_id = table.item(selected[0], "values")[0]
                cursor.execute(
                    "UPDATE resources SET resource_name = ?, resource_type = ?, campus_id = ? "
                    "WHERE resource_id = ?",
                    (name, resource_type, campus_id, resource_id)
                )
                success_message = "The resource has been updated."
            else:
                cursor.execute(
                    "INSERT INTO resources (resource_name, resource_type, campus_id) "
                    "VALUES (?, ?, ?)",
                    (name, resource_type, campus_id)
                )
                success_message = "The resource has been added."

            connection.commit()
            messagebox.showinfo("Resource Saved", success_message, parent=window)
            load_resources()
        except sqlite3.Error as error:
            messagebox.showerror(
                "Database Error", "Could not save the resource:\n" + str(error),
                parent=window
            )
        finally:
            connection.close()

    def remove_resource():
        selected = table.selection()
        if not selected:
            messagebox.showwarning(
                "No Resource Selected", "Select a resource to remove.", parent=window
            )
            return

        resource_id, resource_name, _resource_type = table.item(selected[0], "values")
        if not messagebox.askyesno(
            "Confirm Removal",
            f"Remove '{resource_name}' from this campus?\n"
            "Resources linked to existing bookings cannot be removed.",
            parent=window
        ):
            return

        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT COUNT(*) FROM bookings WHERE resource_id = ?",
                (resource_id,)
            )
            if cursor.fetchone()[0] > 0:
                messagebox.showerror(
                    "Resource In Use",
                    "This resource has booking records, so it cannot be deleted. "
                    "You can update its details instead.",
                    parent=window
                )
                return

            cursor.execute("DELETE FROM resources WHERE resource_id = ?", (resource_id,))
            connection.commit()
            messagebox.showinfo("Resource Removed", "The resource has been removed.", parent=window)
            load_resources()
        except sqlite3.Error as error:
            messagebox.showerror(
                "Database Error", "Could not remove the resource:\n" + str(error),
                parent=window
            )
        finally:
            connection.close()

    table.bind("<<TreeviewSelect>>", select_resource)
    campus_variable.trace_add("write", load_resources)

    buttons = tk.Frame(window, bg="lightblue")
    buttons.pack(pady=8)
    tk.Button(buttons, text="Add / Save Changes", command=save_resource).pack(side="left", padx=5)
    tk.Button(buttons, text="Clear Fields", command=clear_fields).pack(side="left", padx=5)
    tk.Button(buttons, text="Remove Selected", command=remove_resource).pack(side="left", padx=5)
    tk.Button(buttons, text="Refresh", command=load_resources).pack(side="left", padx=5)
    tk.Button(buttons, text="Close", command=window.destroy).pack(side="left", padx=5)

    load_resources()



def manage_my_bookings(user_id):
    """Display the signed-in user's bookings and allow cancellation."""
    bookings_window = tk.Toplevel(root)
    bookings_window.title("My Bookings")
    bookings_window.geometry("850x420")
    bookings_window.configure(bg="lightblue")

    tk.Label(
        bookings_window,
        text="My Resource Bookings",
        font=("Arial", 15, "bold"),
        bg="lightblue"
    ).pack(pady=12)

    columns = (
        "booking_id",
        "campus",
        "resource",
        "date",
        "start",
        "end",
        "status"
    )

    table = ttk.Treeview(
        bookings_window,
        columns=columns,
        show="headings",
        height=12
    )

    headings = {
        "booking_id": "Booking ID",
        "campus": "Campus",
        "resource": "Resource",
        "date": "Date",
        "start": "Start",
        "end": "End",
        "status": "Status"
    }

    widths = {
        "booking_id": 80,
        "campus": 120,
        "resource": 180,
        "date": 100,
        "start": 70,
        "end": 70,
        "status": 100
    }

    for column in columns:
        table.heading(column, text=headings[column])
        table.column(column, width=widths[column], anchor="center")

    table.pack(fill="both", expand=True, padx=12, pady=8)

    def load_bookings():
        # Remove old rows before refreshing the list.
        for row in table.get_children():
            table.delete(row)

        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT bookings.booking_id, campuses.campus_name, "
                "resources.resource_name, bookings.booking_date, "
                "bookings.start_time, bookings.end_time, bookings.status "
                "FROM bookings "
                "INNER JOIN resources "
                "ON bookings.resource_id = resources.resource_id "
                "INNER JOIN campuses "
                "ON resources.campus_id = campuses.campus_id "
                "WHERE bookings.user_id = ? "
                "ORDER BY bookings.booking_date, bookings.start_time",
                (user_id,)
            )
            records = cursor.fetchall()

            for record in records:
                table.insert("", "end", values=record)

        except sqlite3.Error as error:
            messagebox.showerror(
                "Database Error",
                "Could not load your bookings:\n" + str(error),
                parent=bookings_window
            )
        finally:
            connection.close()

        if not table.get_children():
            # Keep the table open; the label lets the user know it is empty.
            empty_message.config(text="You do not have any bookings yet.")
        else:
            empty_message.config(text="")

    empty_message = tk.Label(
        bookings_window,
        text="",
        bg="lightblue",
        fg="darkblue"
    )
    empty_message.pack(pady=2)

    def cancel_selected_booking():
        selected_items = table.selection()

        if not selected_items:
            messagebox.showwarning(
                "No Booking Selected",
                "Select a booking from the table first.",
                parent=bookings_window
            )
            return

        values = table.item(selected_items[0], "values")
        booking_id = values[0]
        status = values[6]
        booking_date = values[3]
        booking_start = values[4]

        # Cancellation is allowed only before the booking start date/time.
        try:
            booking_start_datetime = datetime.strptime(
                f"{booking_date} {booking_start}", "%Y-%m-%d %H:%M"
            )
        except ValueError:
            messagebox.showerror(
                "Invalid Booking Date",
                "This booking has an invalid date or time and cannot be cancelled automatically.",
                parent=bookings_window
            )
            return

        if booking_start_datetime <= datetime.now():
            messagebox.showinfo(
                "Cannot Cancel Past Booking",
                "Only future bookings can be cancelled. Past or already-started bookings remain in your history.",
                parent=bookings_window
            )
            return

        if status != "Confirmed":
            messagebox.showinfo(
                "Cannot Cancel",
                "Only confirmed bookings can be cancelled.",
                parent=bookings_window
            )
            return

        confirmed = messagebox.askyesno(
            "Confirm Cancellation",
            f"Are you sure you want to cancel booking #{booking_id}?",
            parent=bookings_window
        )
        if not confirmed:
            return

        connection = get_connection()
        try:
            cursor = connection.cursor()
            # The user_id condition ensures users can cancel only their own booking.
            cursor.execute(
                "UPDATE bookings SET status = 'Cancelled' "
                "WHERE booking_id = ? AND user_id = ? "
                "AND status = 'Confirmed'",
                (booking_id, user_id)
            )
            connection.commit()

            if cursor.rowcount == 1:
                messagebox.showinfo(
                    "Booking Cancelled",
                    f"Booking #{booking_id} has been cancelled.",
                    parent=bookings_window
                )
                load_bookings()
            else:
                messagebox.showwarning(
                    "Cancellation Not Completed",
                    "This booking could not be cancelled. It may already "
                    "have been cancelled or may not belong to your account.",
                    parent=bookings_window
                )
        except sqlite3.Error as error:
            messagebox.showerror(
                "Database Error",
                "Could not cancel the booking:\n" + str(error),
                parent=bookings_window
            )
        finally:
            connection.close()

    button_frame = tk.Frame(bookings_window, bg="lightblue")
    button_frame.pack(pady=10)

    tk.Button(
        button_frame,
        text="Cancel Selected Booking",
        command=cancel_selected_booking
    ).pack(side="left", padx=8)

    tk.Button(
        button_frame,
        text="Refresh",
        command=load_bookings
    ).pack(side="left", padx=8)

    tk.Button(
        button_frame,
        text="Close",
        command=bookings_window.destroy
    ).pack(side="left", padx=8)

    load_bookings()



def open_system_reports():
    """Show institution-wide booking statistics and compare campus policies."""
    window = tk.Toplevel(root)
    window.title("Campus Reports and Comparison")
    window.geometry("1120x600")
    window.configure(bg="lightblue")

    tk.Label(
        window,
        text="Campus Usage Reports and Comparison",
        font=("Arial", 15, "bold"),
        bg="lightblue"
    ).pack(pady=10)

    columns = (
        "campus", "total_bookings", "active_bookings", "top_resource",
        "average_duration", "policy"
    )
    table = ttk.Treeview(window, columns=columns, show="headings", height=14)
    labels = {
        "campus": "Campus",
        "total_bookings": "Total Records",
        "active_bookings": "Non-cancelled",
        "top_resource": "Most Used Resource",
        "average_duration": "Average Duration (hours)",
        "policy": "Campus Policy"
    }
    widths = {
        "campus": 135, "total_bookings": 105, "active_bookings": 115,
        "top_resource": 220, "average_duration": 165, "policy": 300
    }
    for column in columns:
        table.heading(column, text=labels[column])
        table.column(column, width=widths[column], anchor="center")
    table.pack(fill="both", expand=True, padx=12, pady=10)

    summary = tk.Label(
        window, text="", bg="lightblue", justify="left", anchor="w",
        wraplength=1080
    )
    summary.pack(fill="x", padx=14, pady=5)

    def load_report():
        for item in table.get_children():
            table.delete(item)

        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT campus_id, campus_name, max_duration, start_hour, end_hour "
                "FROM campuses ORDER BY campus_name"
            )
            campuses = cursor.fetchall()
            report_rows = []

            for campus_id, campus_name, max_duration, start_hour, end_hour in campuses:
                cursor.execute(
                    "SELECT COUNT(b.booking_id), "
                    "SUM(CASE WHEN b.booking_id IS NOT NULL "
                    "AND COALESCE(b.status, '') != 'Cancelled' THEN 1 ELSE 0 END) "
                    "FROM resources r LEFT JOIN bookings b ON b.resource_id = r.resource_id "
                    "WHERE r.campus_id = ?",
                    (campus_id,)
                )
                count_row = cursor.fetchone()
                total_bookings = count_row[0] or 0
                active_bookings = count_row[1] or 0

                cursor.execute(
                    "SELECT r.resource_name, COUNT(b.booking_id) AS usage_count "
                    "FROM resources r LEFT JOIN bookings b "
                    "ON b.resource_id = r.resource_id "
                    "AND COALESCE(b.status, '') != 'Cancelled' "
                    "WHERE r.campus_id = ? "
                    "GROUP BY r.resource_id, r.resource_name "
                    "ORDER BY usage_count DESC, r.resource_name LIMIT 1",
                    (campus_id,)
                )
                top_row = cursor.fetchone()
                if top_row and top_row[1] > 0:
                    top_resource = f"{top_row[0]} ({top_row[1]})"
                elif top_row:
                    top_resource = f"{top_row[0]} (no active use)"
                else:
                    top_resource = "No resources"

                cursor.execute(
                    "SELECT AVG((CAST(substr(b.end_time, 1, 2) AS INTEGER) * 60 + "
                    "CAST(substr(b.end_time, 4, 2) AS INTEGER) - "
                    "CAST(substr(b.start_time, 1, 2) AS INTEGER) * 60 - "
                    "CAST(substr(b.start_time, 4, 2) AS INTEGER)) / 60.0) "
                    "FROM bookings b INNER JOIN resources r "
                    "ON r.resource_id = b.resource_id "
                    "WHERE r.campus_id = ? AND COALESCE(b.status, '') != 'Cancelled'",
                    (campus_id,)
                )
                average = cursor.fetchone()[0]
                average_text = f"{average:.2f}" if average is not None else "N/A"
                policy_text = (
                    f"Max {float(max_duration):g} h; "
                    f"{int(start_hour):02d}:00-{int(end_hour):02d}:00"
                )
                table.insert(
                    "", "end",
                    values=(campus_name, total_bookings, active_bookings,
                            top_resource, average_text, policy_text)
                )
                report_rows.append((campus_name, total_bookings, active_bookings,
                                    top_resource, average_text, policy_text))

            if report_rows:
                highest = max(report_rows, key=lambda row: (row[1], row[0]))
                most_active = max(report_rows, key=lambda row: (row[2], row[0]))
                policies = "; ".join(
                    f"{row[0]}: {row[5]}" for row in report_rows
                )
                summary.config(
                    text=(
                        f"Comparison: {highest[0]} has the most booking records "
                        f"({highest[1]}), while {most_active[0]} has the most "
                        f"non-cancelled bookings ({most_active[2]}). Policies differ "
                        f"between campuses and may influence when or how long resources "
                        f"can be booked; these figures show usage patterns but do not "
                        f"by themselves prove that a policy caused a difference.\n"
                        f"Configured policies: {policies}"
                    )
                )
            else:
                summary.config(text="No campus data is available for comparison.")
        except (sqlite3.Error, TypeError, ValueError) as error:
            messagebox.showerror(
                "Report Error", "Could not generate reports:\n" + str(error),
                parent=window
            )
        finally:
            connection.close()

    controls = tk.Frame(window, bg="lightblue")
    controls.pack(pady=8)
    tk.Button(controls, text="Refresh Reports", command=load_report).pack(side="left", padx=5)
    tk.Button(controls, text="Close", command=window.destroy).pack(side="left", padx=5)
    load_report()



def open_admin_booking_overview():
    """Let campus administrators review bookings and usage trends by campus."""
    campuses = get_campuses()
    if not campuses:
        messagebox.showerror(
            "No Campuses", "No campuses are available in the database."
        )
        return

    window = tk.Toplevel(root)
    window.title("Campus Bookings and Usage Trends")
    window.geometry("1100x680")
    window.configure(bg="lightblue")

    tk.Label(
        window,
        text="Campus Booking Overview and Resource Usage",
        font=("Arial", 16, "bold"),
        bg="lightblue"
    ).pack(pady=(12, 5))

    selector = tk.Frame(window, bg="lightblue")
    selector.pack(fill="x", padx=12, pady=6)
    tk.Label(selector, text="Campus:", font=("Arial", 11, "bold"), bg="lightblue").pack(side="left", padx=5)
    campus_variable = tk.StringVar(window, value=selected_campus.get() if selected_campus.get() in campuses else campuses[0])
    campus_menu = tk.OptionMenu(selector, campus_variable, *campuses)
    campus_menu.pack(side="left", padx=5)
    tk.Label(
        selector,
        text="Choose a campus to view its bookings and resource usage.",
        bg="lightblue"
    ).pack(side="left", padx=12)

    tk.Label(
        window, text="Bookings for selected campus", font=("Arial", 12, "bold"), bg="lightblue"
    ).pack(anchor="w", padx=14, pady=(8, 2))

    booking_columns = ("booking_id", "lecturer", "resource", "date", "start", "end", "status")
    booking_table = ttk.Treeview(window, columns=booking_columns, show="headings", height=11)
    booking_headers = {
        "booking_id": "Booking ID", "lecturer": "Lecturer", "resource": "Resource",
        "date": "Date", "start": "Start Time", "end": "End Time", "status": "Status"
    }
    booking_widths = {"booking_id": 85, "lecturer": 190, "resource": 220, "date": 110,
                      "start": 90, "end": 90, "status": 100}
    for column in booking_columns:
        booking_table.heading(column, text=booking_headers[column])
        booking_table.column(column, width=booking_widths[column], anchor="center")
    booking_table.pack(fill="both", expand=True, padx=12, pady=5)

    tk.Label(
        window, text="Resource usage trends", font=("Arial", 12, "bold"), bg="lightblue"
    ).pack(anchor="w", padx=14, pady=(10, 2))
    usage_columns = ("resource", "type", "total", "active", "hours")
    usage_table = ttk.Treeview(window, columns=usage_columns, show="headings", height=6)
    usage_headers = {
        "resource": "Resource", "type": "Type", "total": "Total Bookings",
        "active": "Non-cancelled Bookings", "hours": "Hours Booked"
    }
    usage_widths = {"resource": 300, "type": 200, "total": 150, "active": 190, "hours": 150}
    for column in usage_columns:
        usage_table.heading(column, text=usage_headers[column])
        usage_table.column(column, width=usage_widths[column], anchor="center")
    usage_table.pack(fill="x", padx=12, pady=5)

    summary = tk.Label(
        window, text="", bg="lightblue", justify="left", anchor="w", wraplength=1050
    )
    summary.pack(fill="x", padx=14, pady=6)

    def load_overview(*args):
        for table in (booking_table, usage_table):
            for item in table.get_children():
                table.delete(item)

        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT b.booking_id, u.full_name, r.resource_name, b.booking_date, "
                "b.start_time, b.end_time, b.status "
                "FROM bookings b "
                "INNER JOIN users u ON u.user_id = b.user_id "
                "INNER JOIN resources r ON r.resource_id = b.resource_id "
                "INNER JOIN campuses c ON c.campus_id = r.campus_id "
                "WHERE c.campus_name = ? "
                "ORDER BY b.booking_date DESC, b.start_time DESC, b.booking_id DESC",
                (campus_variable.get(),)
            )
            bookings = cursor.fetchall()
            for record in bookings:
                booking_table.insert("", "end", values=record)

            cursor.execute(
                "SELECT r.resource_name, r.resource_type, COUNT(b.booking_id), "
                "SUM(CASE WHEN b.status IS NULL OR b.status != 'Cancelled' THEN 1 ELSE 0 END), "
                "COALESCE(SUM(CASE WHEN b.status IS NULL OR b.status != 'Cancelled' "
                "THEN ((CAST(substr(b.end_time,1,2) AS INTEGER)*60 + "
                "CAST(substr(b.end_time,4,2) AS INTEGER)) - "
                "(CAST(substr(b.start_time,1,2) AS INTEGER)*60 + "
                "CAST(substr(b.start_time,4,2) AS INTEGER))) / 60.0 ELSE 0 END), 0) "
                "FROM resources r "
                "INNER JOIN campuses c ON c.campus_id = r.campus_id "
                "LEFT JOIN bookings b ON b.resource_id = r.resource_id "
                "WHERE c.campus_name = ? "
                "GROUP BY r.resource_id, r.resource_name, r.resource_type "
                "ORDER BY COUNT(b.booking_id) DESC, r.resource_name",
                (campus_variable.get(),)
            )
            usage_records = cursor.fetchall()
            for resource_name, resource_type, total, active, hours in usage_records:
                usage_table.insert(
                    "", "end",
                    values=(resource_name, resource_type, total, active, f"{hours:.2f}")
                )

            active_bookings = sum(1 for row in bookings if row[6] != "Cancelled")
            if usage_records:
                most_used = max(usage_records, key=lambda row: (row[3], row[0]))
                total_hours = sum(float(row[4] or 0) for row in usage_records)
                summary.config(
                    text=f"{campus_variable.get()}: {len(bookings)} booking records, "
                    f"{active_bookings} non-cancelled bookings, and {total_hours:.2f} total hours "
                    f"booked. Most-used resource by non-cancelled booking count: "
                    f"{most_used[0]} ({most_used[3]} bookings)."
                )
            else:
                summary.config(text=f"{campus_variable.get()} has no registered resources or booking records yet.")
        except sqlite3.Error as error:
            messagebox.showerror(
                "Database Error", "Could not load campus booking information:\n" + str(error),
                parent=window
            )
        finally:
            connection.close()

    campus_variable.trace_add("write", load_overview)
    controls = tk.Frame(window, bg="lightblue")
    controls.pack(pady=8)
    tk.Button(controls, text="Refresh Overview", command=load_overview).pack(side="left", padx=5)
    tk.Button(controls, text="Close", command=window.destroy).pack(side="left", padx=5)
    load_overview()


def open_dashboard(user_id, full_name, role):
    dashboard = tk.Toplevel(root)
    dashboard.title(role + " Dashboard")
    dashboard.geometry("450x350")
    dashboard.configure(bg="lightblue")

    tk.Label(
        dashboard,
        text="Welcome, " + full_name + "!",
        font=("Arial", 16, "bold"),
        bg="lightblue"
    ).pack(pady=20)

    tk.Label(
        dashboard,
        text="Role: " + role,
        font=("Arial", 12),
        bg="lightblue"
    ).pack(pady=5)

    active_campus_label = tk.Label(
        dashboard,
        text="Active Campus: " + (selected_campus.get() or "Not selected"),
        font=("Arial", 11, "bold"),
        fg="darkgreen", bg="lightblue"
    )
    active_campus_label.pack(pady=5)

    def refresh_active_campus(*args):
        active_campus_label.config(
            text="Active Campus: " + (selected_campus.get() or "Not selected")
        )

    selected_campus.trace_add("write", refresh_active_campus)

    if role == "Lecturer":
        tk.Button(
            dashboard,
            text="View Campus Resources",
            command=view_campus_resources
        ).pack(pady=10)

        tk.Button(
            dashboard,
            text="Make a Booking",
            command=lambda: open_booking_form(user_id)
        ).pack(pady=10)

        tk.Button(
            dashboard,
            text="View / Cancel My Bookings",
            command=lambda: manage_my_bookings(user_id)
        ).pack(pady=10)

    elif role == "Campus Administrator":
        tk.Button(
            dashboard,
            text="Manage Campus Resources",
            command=manage_campus_resources
        ).pack(pady=8)

        tk.Button(
            dashboard,
            text="View Campus Bookings and Usage Trends",
            command=open_admin_booking_overview
        ).pack(pady=8)

    elif role == "System Operator":
        tk.Button(
            dashboard,
            text="System Reports and Campus Comparison",
            command=open_system_reports
        ).pack(pady=10)

    tk.Button(
        dashboard,
        text="Logout",
        command=dashboard.destroy
    ).pack(pady=20)


def login_user():
    login_window = tk.Toplevel(root)
    login_window.title("User Login")
    login_window.geometry("300x220")
    login_window.configure(bg="lightblue")

    tk.Label(login_window, text="Username:", bg="lightblue").pack(pady=5)
    username_entry = tk.Entry(login_window)
    username_entry.pack()

    tk.Label(login_window, text="Password:", bg="lightblue").pack(pady=5)
    password_entry = tk.Entry(login_window, show="*")
    password_entry.pack()

    def check_login():
        username = username_entry.get().strip()
        password = password_entry.get()

        if not username or not password:
            messagebox.showwarning(
                "Missing Information",
                "Please enter your username and password.",
                parent=login_window
            )
            return

        password_hash = hashlib.sha256(password.encode("utf-8")).hexdigest()
        connection = get_connection()
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT user_id, full_name, role FROM users "
                "WHERE username = ? AND password_hash = ?",
                (username, password_hash)
            )
            user = cursor.fetchone()
        finally:
            connection.close()

        if user:
            user_id, full_name, role = user
            authenticated_user = create_user_role(user_id, full_name, role)
            login_window.destroy()
            open_dashboard(
                authenticated_user.user_id,
                authenticated_user.full_name,
                authenticated_user.role
            )
        else:
            messagebox.showerror(
                "Login Failed",
                "Incorrect username or password.",
                parent=login_window
            )

    tk.Button(
        login_window,
        text="Login",
        command=check_login
    ).pack(pady=15)


# Build the main application window.
root = tk.Tk()
root.title("Smart Campus Resource Booking System")
root.geometry("600x600")
root.configure(bg="lightblue")

campus_options = get_campuses()
selected_campus = tk.StringVar(root)

if campus_options:
    selected_campus.set(campus_options[0])

tk.Label(
    root,
    text="Smart Campus Resource Booking System",
    font=("Arial", 16, "bold"),
    bg="lightblue"
).pack(pady=20)

tk.Label(
    root,
    text="Welcome to the booking system!",
    font=("Arial", 12),
    bg="lightblue"
).pack(pady=10)

tk.Label(
    root,
    text="Please select your campus:",
    font=("Arial", 11),
    bg="lightblue"
).pack(pady=5)

if campus_options:
    tk.OptionMenu(root, selected_campus, *campus_options).pack(pady=10)
else:
    tk.Label(
        root,
        text="No campuses found. Please check the database.",
        bg="lightblue"
    ).pack(pady=10)

tk.Button(
    root,
    text="Select Campus",
    command=select_campus
).pack(pady=8)

tk.Button(
    root,
    text="Booking Information",
    command=show_booking_message
).pack(pady=5)

tk.Button(
    root,
    text="View Campus Resources",
    command=view_campus_resources
).pack(pady=5)

tk.Button(
    root,
    text="Register User",
    command=register_user
).pack(pady=5)

tk.Button(
    root,
    text="Login",
    command=login_user
).pack(pady=5)

tk.Button(
    root,
    text="Exit",
    command=root.destroy
).pack(pady=10)

root.mainloop()
