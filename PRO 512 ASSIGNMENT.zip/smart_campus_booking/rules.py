class CampusBookingPolicy:
    """Encapsulate booking constraints for a campus, separate from GUI logic."""

    def __init__(self, campus_name, max_duration, opening_hour, closing_hour):
        self.campus_name = campus_name
        self.max_duration = float(max_duration)
        self.opening_hour = int(opening_hour)
        self.closing_hour = int(closing_hour)

    def validate(self, start, end):
        """Return an explanatory error string, or None if the booking is valid."""
        duration = ((end.hour * 60 + end.minute) -
                    (start.hour * 60 + start.minute)) / 60
        if duration > self.max_duration:
            return (f"{self.campus_name} allows bookings of up to "
                    f"{self.max_duration:g} hours.")
        if start.hour < self.opening_hour:
            return f"{self.campus_name} opens at {self.opening_hour:02d}:00."
        if end.hour > self.closing_hour or (end.hour == self.closing_hour and end.minute > 0):
            return (f"{self.campus_name} closes at {self.closing_hour:02d}:00. "
                    "Please choose a time within operating hours.")
        return None
