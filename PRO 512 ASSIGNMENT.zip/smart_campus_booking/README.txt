SMART CAMPUS RESOURCE BOOKING SYSTEM
====================================

A desktop application (Python + Tkinter + SQLite) for booking campus
resources such as lecture rooms, computer labs and projectors.


REQUIREMENTS
------------
- Python 3.8 or newer (https://www.python.org/downloads/)
  On Windows, tick "Add Python to PATH" during installation.
- Tkinter (included with the standard Windows and macOS Python installers).
  On some Linux systems install it with:  sudo apt install python3-tk
- No extra packages are needed. sqlite3, hashlib and tkinter all come with
  Python.


PROJECT FILES
-------------
Keep all files together in ONE folder:

  smart_campus_booking/
  |-- main.py            Starts the program (run this file)
  |-- database.py        Creates tables, adds campuses/resources, DB helpers
  |-- models.py          User classes (Lecturer, Campus Administrator,
  |                      System Operator)
  |-- rules.py           Campus booking rules (max duration, operating hours)
  |-- gui.py             All Tkinter windows
  |-- campus_booking.db  Database file (created automatically on first run)
  |-- README.txt         This file


HOW TO RUN
----------
1. Copy all the .py files into one folder.

2. Open a terminal or command prompt in that folder.
   Windows: open the folder in File Explorer, click the address bar,
            type  cmd  and press Enter.

3. Run:

       python main.py

   (If that does not work, try:  py main.py   or   python3 main.py)

4. The first run creates campus_booking.db automatically, adds the three
   campuses (Pretoria, Centurion, Polokwane) and sample resources.
   The main window then opens.

IMPORTANT: Always run main.py. Do not run gui.py directly, because the
database is prepared by main.py before the window opens.

You can also open the folder in an editor such as PyCharm or VS Code and
run main.py from there.


HOW TO USE THE SYSTEM
---------------------
1. Register: click "Register User", enter your full name, a username and a
   password, choose a role, then click Register.

2. Login: click "Login" and enter your username and password.

3. What each role can do after logging in:

   Lecturer
   - View campus resources
   - Make a booking (choose campus, resource, date and times)
   - View and cancel your own future bookings

   Campus Administrator
   - Add, update and remove campus resources
   - View bookings and resource usage trends for each campus

   System Operator
   - View institution-wide reports and compare campus policies


BOOKING RULES
-------------
- Date format: YYYY-MM-DD (example: 2026-11-05)
- Time format: HH:MM, 24-hour (example: 09:30)
- Bookings must start in the future.
- The end time must be later than the start time.
- A resource cannot be booked if it overlaps another confirmed booking.
- Each campus has its own limits:

    Campus      Max duration   Operating hours
    Pretoria    2 hours        08:00 - 16:00
    Centurion   3 hours        08:00 - 18:00
    Polokwane   4 hours        09:00 - 17:00

- Only confirmed bookings that have not started yet can be cancelled.


TROUBLESHOOTING
---------------
- "ImportError: cannot import name 'get_connection' from 'database'"
  Make sure you are using the database.py from this project, and that no
  other file named database.py is in the folder.

- "ModuleNotFoundError: No module named 'tkinter'"
  Reinstall Python and include Tcl/Tk, or on Linux run:
  sudo apt install python3-tk

- "python is not recognized" (Windows)
  Use  py main.py  or reinstall Python with "Add Python to PATH" ticked.

- No campuses or resources appear
  Close the program, delete campus_booking.db and run main.py again.
  A fresh database will be created. (This also deletes any registered
  users and bookings.)

- Running from a different folder creates a second database
  campus_booking.db is stored next to the .py files, so it is always the
  same file regardless of where you start the program from.
