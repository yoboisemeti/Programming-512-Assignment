class User:
    """Base class for authenticated system users."""

    def __init__(self, user_id, full_name, role):
        self.__user_id = user_id
        self.__full_name = full_name
        self.__role = role

    @property
    def user_id(self):
        return self.__user_id

    @property
    def full_name(self):
        return self.__full_name

    @property
    def role(self):
        return self.__role


class Lecturer(User):
    """User role that can book resources and manage personal bookings."""


class CampusAdministrator(User):
    """User role that manages campus resources."""


class SystemOperator(User):
    """User role that can view institution-wide reports."""


def create_user_role(user_id, full_name, role):
    """Return a role-specific User object."""
    role_classes = {
        "Lecturer": Lecturer,
        "Campus Administrator": CampusAdministrator,
        "System Operator": SystemOperator
    }
    user_class = role_classes.get(role, User)
    return user_class(user_id, full_name, role)
