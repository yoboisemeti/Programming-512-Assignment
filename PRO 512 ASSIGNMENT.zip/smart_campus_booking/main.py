import sqlite3

from database import initialize_database


# Prepare the database before any screen queries campus data.
try:
    initialize_database()
except sqlite3.Error as error:
    # The GUI has not been created yet, so print a clear diagnostic and stop.
    raise RuntimeError(
        "Could not initialize campus_booking.db. Check the database file and permissions. "
        f"Details: {error}"
    ) from error

# Importing gui builds the main window and starts the Tkinter main loop.
import gui
