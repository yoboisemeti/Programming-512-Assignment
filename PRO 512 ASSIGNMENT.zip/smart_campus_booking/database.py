import sqlite3
import os

DATABASE_NAME = os.path.join(os.path.dirname(os.path.abspath(__file__)), "campus_booking.db")


def get_connection():
    """Open the application database and enable SQLite foreign-key checks."""
    connection = sqlite3.connect(DATABASE_NAME)
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database():
    # Connect to the database
    connection = get_connection()

    try:
        # Create a cursor to execute SQL commands
        cursor = connection.cursor()

        # Create the users table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL
        )
        """)

        # Create the campuses table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS campuses (
        campus_id INTEGER PRIMARY KEY AUTOINCREMENT,
        campus_name TEXT UNIQUE NOT NULL,
        max_duration INTEGER NOT NULL,
        start_hour INTEGER NOT NULL,
        end_hour INTEGER NOT NULL
        )
        """)

        # Create the resources table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS resources (
        resource_id INTEGER PRIMARY KEY AUTOINCREMENT,
        resource_name TEXT NOT NULL,
        resource_type TEXT NOT NULL,
        campus_id INTEGER NOT NULL,
        FOREIGN KEY (campus_id) REFERENCES campuses(campus_id)
        )
        """)

        # Create the bookings table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS bookings (
        booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        resource_id INTEGER NOT NULL,
        booking_date TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        status TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (resource_id) REFERENCES resources(resource_id)
        )
        """)

        # Add the three campuses to the database

        # Remove the old example campuses
        cursor.execute(
            "DELETE FROM campuses "
            "WHERE campus_name IN ('Campus A', 'Campus B', 'Campus C')"
        )

        # Add the actual campus names
        campuses = [
            ("Pretoria", 2, 8, 16),
            ("Centurion", 3, 8, 18),
            ("Polokwane", 4, 9, 17)
        ]

        cursor.executemany(
            "INSERT OR IGNORE INTO campuses "
            "(campus_name, max_duration, start_hour, end_hour) "
            "VALUES (?, ?, ?, ?)",
            campuses
        )

        # Add resources to each campus
        cursor.execute("SELECT campus_id, campus_name FROM campuses")
        campus_records = cursor.fetchall()

        resources = {
            "Pretoria": [
                ("Lecture Room 1", "Lecture Room"),
                ("Computer Lab 1", "Computer Lab"),
                ("Projector 1", "Projector")
            ],
            "Centurion": [
                ("Lecture Room 2", "Lecture Room"),
                ("Computer Lab 2", "Computer Labo"),
                ("Projector 2", "Projector")
            ],
            "Polokwane": [
                ("Lecture Room 3", "Lecture Room"),
                ("Computer Lab 3", "Computer Lab"),
                ("Projector 3", "Projector")
            ]
        }

        for campus_id, campus_name in campus_records:
            for resource_name, resource_type in resources[campus_name]:
                cursor.execute(
                    "SELECT resource_id FROM resources "
                    "WHERE resource_name = ? AND campus_id = ?",
                    (resource_name, campus_id)
                )

                existing_resource = cursor.fetchone()

                if existing_resource is None:
                    cursor.execute(
                        "INSERT INTO resources "
                        "(resource_name, resource_type, campus_id) "
                        "VALUES (?, ?, ?)",
                        (resource_name, resource_type, campus_id)
                    )

        connection.commit()
    finally:
        # Close the database connection
        connection.close()


def get_campuses():
    connection = get_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT campus_name FROM campuses ORDER BY campus_id")
    campuses = [row[0] for row in cursor.fetchall()]
    connection.close()
    return campuses
